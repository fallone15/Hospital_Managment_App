// Configuration de l'API
const API_URL = 'http://localhost:5000/api';

// === État du formulaire multi-étapes ===
let currentStep = 1;
const totalSteps = 4;

// === Initialisation de intl-tel-input ===
const phoneInput = document.querySelector("#phone");
const iti = window.intlTelInput(phoneInput, {
    initialCountry: "ma", // Maroc par défaut
    preferredCountries: ["ma", "fr", "be", "dz", "tn"], // Pays prioritaires
    separateDialCode: true, // Afficher l'indicatif séparément
    utilsScript: "https://cdn.jsdelivr.net/npm/intl-tel-input@19.5.6/build/js/utils.js"
});

// === Éléments du DOM ===
const form = document.getElementById("registerForm");
const successBox = document.getElementById("successMessage");
const cardNumberSpan = document.getElementById("cardNumber");
const phoneError = document.getElementById("phoneError");

// === Navigation entre étapes ===
function showStep(stepNumber) {
    // Masquer toutes les étapes
    document.querySelectorAll('.form-step').forEach(step => {
        step.classList.remove('active');
    });

    // Afficher l'étape actuelle
    const currentStepElement = document.querySelector(`.form-step[data-step="${stepNumber}"]`);
    if (currentStepElement) {
        currentStepElement.classList.add('active');
    }

    // Mettre à jour le stepper
    updateStepper(stepNumber);

    // Si c'est la dernière étape, afficher le récapitulatif
    if (stepNumber === totalSteps) {
        displaySummary();
    }

    // Scroll vers le haut
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function updateStepper(stepNumber) {
    document.querySelectorAll('.step').forEach((step, index) => {
        const stepNum = index + 1;

        // Retirer toutes les classes
        step.classList.remove('active', 'completed');

        // Ajouter la classe appropriée
        if (stepNum < stepNumber) {
            step.classList.add('completed');
        } else if (stepNum === stepNumber) {
            step.classList.add('active');
        }
    });
}

function nextStep() {
    if (validateCurrentStep()) {
        if (currentStep < totalSteps) {
            currentStep++;
            showStep(currentStep);
        }
    }
}

function prevStep() {
    if (currentStep > 1) {
        currentStep--;
        showStep(currentStep);
    }
}

// === Validation par étape ===
function validateCurrentStep() {
    const currentStepElement = document.querySelector(`.form-step[data-step="${currentStep}"]`);
    const inputs = currentStepElement.querySelectorAll('input[required], select[required]');
    let valid = true;

    inputs.forEach(input => {
        // Ignorer le téléphone (validation spéciale)
        if (input.id === 'phone') {
            if (!iti.isValidNumber()) {
                input.style.borderColor = '#e74c3c';
                if (phoneError) {
                    phoneError.style.display = 'block';
                }
                valid = false;
            } else {
                input.style.borderColor = '#4CAF50';
                if (phoneError) {
                    phoneError.style.display = 'none';
                }
            }
            return;
        }

        // Validation email
        if (input.type === 'email' && input.value.trim()) {
            if (!validateEmail(input.value.trim())) {
                input.style.borderColor = '#e74c3c';
                alert("L'email doit se terminer par @gmail.com");
                valid = false;
                return;
            }
        }

        // Validation champs requis
        if (!input.value.trim()) {
            input.style.borderColor = '#e74c3c';
            valid = false;
        } else {
            input.style.borderColor = '#4CAF50';
        }
    });

    if (!valid) {
        alert("Merci de remplir correctement tous les champs obligatoires !");
    }

    return valid;
}

// === Validation email (doit finir par @gmail.com) ===
function validateEmail(email) {
    return /^[a-zA-Z0-9._%+-]+@gmail\.com$/i.test(email);
}

// === Afficher le récapitulatif ===
function displaySummary() {
    const summaryContent = document.getElementById('summaryContent');

    const data = {
        "Nom": document.getElementById('nom').value.toUpperCase(),
        "Prénom": document.getElementById('prenom').value,
        "Date de naissance": document.getElementById('dateNaissance').value,
        "Sexe": document.getElementById('sexe').value,
        "Adresse": document.getElementById('adresse').value,
        "Code Postal": document.getElementById('codePostal').value,
        "Ville": document.getElementById('ville').value,
        "Email": document.getElementById('email').value,
        "CIN": document.getElementById('cin').value,
        "Téléphone": iti.getNumber(),
        "Numéro de Sécurité Sociale": document.getElementById('numeroSecu').value || "Non renseigné",
        "Mutuelle": document.getElementById('mutuelle').value || "Non renseigné",
        "Groupe Sanguin": document.getElementById('groupeSanguin').value || "Non renseigné",
        "Allergies": document.getElementById('allergies').value || "Aucune"
    };

    let html = '';
    for (const [label, value] of Object.entries(data)) {
        html += `
            <div class="summary-item">
                <span class="summary-label">${label}</span>
                <span class="summary-value">${value}</span>
            </div>
        `;
    }

    summaryContent.innerHTML = html;
}

// === Gestion des boutons de navigation ===
document.addEventListener('click', function (e) {
    if (e.target.classList.contains('btn-next') || e.target.closest('.btn-next')) {
        e.preventDefault();
        nextStep();
    }

    if (e.target.classList.contains('btn-prev') || e.target.closest('.btn-prev')) {
        e.preventDefault();
        prevStep();
    }
});

// === Masquer l'erreur téléphone lors de la saisie ===
phoneInput.addEventListener('input', function () {
    if (iti.isValidNumber()) {
        phoneInput.style.borderColor = '#4CAF50';
        if (phoneError) {
            phoneError.style.display = 'none';
        }
    }
});

phoneInput.addEventListener('countrychange', function () {
    if (phoneInput.value.trim() && iti.isValidNumber()) {
        phoneInput.style.borderColor = '#4CAF50';
        if (phoneError) {
            phoneError.style.display = 'none';
        }
    }
});

// === Gestion de la soumission du formulaire ===
form.addEventListener("submit", async function (e) {
    e.preventDefault();

    if (!validateCurrentStep()) {
        return;
    }

    // Préparer les allergies sous forme de tableau
    const allergiesInput = document.getElementById('allergies').value;
    const allergies = allergiesInput
        ? allergiesInput.split(',').map(a => a.trim())
        : [];

    // Préparer les données pour l'API
    const formData = {
        nom: document.getElementById('nom').value.toUpperCase(),
        prenom: document.getElementById('prenom').value,
        date_naissance: document.getElementById('dateNaissance').value,
        sexe: document.getElementById('sexe').value,
        adresse: document.getElementById('adresse').value,
        code_postal: document.getElementById('codePostal').value,
        ville: document.getElementById('ville').value,
        email: document.getElementById('email').value,
        cin: document.getElementById('cin').value,
        telephone: iti.getNumber(), // Numéro complet international
        numero_secu: document.getElementById('numeroSecu').value,
        mutuelle: document.getElementById('mutuelle').value,
        allergies: allergies,
        groupe_sanguin: document.getElementById('groupeSanguin').value || null,
        code_pin: document.getElementById('pin').value
    };

    console.log('📤 Envoi des données:', formData);

    try {
        // Envoyer la requête au backend
        const response = await fetch(`${API_URL}/auth/register/patient`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        const result = await response.json();
        console.log('📥 Réponse du serveur:', result);

        if (result.success) {
            // Sauvegarder le token
            localStorage.setItem('token', result.data.token);
            localStorage.setItem('carte_rfid', result.data.patient.carte_rfid);
            localStorage.setItem('user', JSON.stringify(result.data.patient));

            // Afficher le numéro de carte RFID
            cardNumberSpan.textContent = result.data.patient.carte_rfid;

            // Masquer le formulaire
            form.parentElement.style.display = "none";

            // Afficher le message de succès
            successBox.classList.remove("hidden");

            // Redirection vers login après 5 secondes
            setTimeout(() => {
                window.location.href = "login.html";
            }, 5000);
        } else {
            alert("❌ Erreur : " + result.message);
        }
    } catch (error) {
        console.error('❌ Erreur de connexion:', error);
        alert("❌ Erreur de connexion au serveur. Vérifiez que le backend est démarré sur le port 5000.");
    }
});

// === Initialisation ===
document.addEventListener('DOMContentLoaded', function () {
    showStep(1);
});